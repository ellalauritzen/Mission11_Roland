export interface CartItem {
  bookId: number;
  title: string;
  quantity: number;
  price: number;
  subtotal: number;
  total: number;
}