function WelcomeBand(){
    return (
        <div className="row bg-primary text-white">
            <div className="col-12 text-center">
                <h1>Welcome to the Bookstore</h1>
            </div>
        </div>
)
}

export default WelcomeBand;